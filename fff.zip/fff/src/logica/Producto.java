package logica;

public interface Producto {
	public default String getNombre() {
		return getNombre();
		}
	public default int getPrecio() {
		return getPrecio();
		}
	public default String generarTextoFactura() {
		return generarTextoFactura();
		}
	
	
		
	}


